public class TimeDeFutebol{
  	private int numTorcida;
  //getter
	public int numTorcida(){
        	return numTorcida;
	}
  //setter
   	public void setnumTorcida(int numTorcida){
		this.numTorcida = numTorcida;   
   	} 
}