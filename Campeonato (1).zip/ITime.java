public interface ITime{
  public String printNomeTime();
  public void adicionarVitoria();
  public void adicionarEmpate();
  public void adicionarDerrota();
  public int totalPontos();
  public int getVitoria();
  public int getEmpate();
  public int getDerrota();
  public int totaljogo();
}